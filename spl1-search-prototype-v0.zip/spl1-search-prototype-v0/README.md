# Mini IIT Search Prototype — Version 0.1

Rifat Al Maruf (BSSE1705), SPL-1, IIT, University of Dhaka.

## 1. What this prototype is
A tiny offline Java demonstration of classical information retrieval. Six short,
fictional academic documents illustrate the future IIT search engine. They are
not official IIT documents. This is a learning prototype, not the final project.
No external dependencies, frameworks, network access, or database are used.

## 2. Problem it demonstrates
Find documents relevant to keywords without opening every document manually.
Index documents once, then look up query words in that index.

## 3. Input
UTF-8 `.txt` files directly inside `data/`, plus terminal keyword queries.
Filenames are retained but are not indexed. Files are loaded alphabetically and
receive IDs starting at 1. IDs may change after files are added or removed.

## 4. Processing pipeline
1. Read each file using standard Java file I/O.
2. Lowercase text and scan characters manually into words. Only ASCII letters
   a–z and digits 0–9 are retained; other characters separate words.
3. Remove these stop words: a, an, the, and, or, is, are, of, to, in, for, with.
4. Build `term -> (document ID -> occurrence count)` using nested HashMaps.
5. Apply the same preprocessing to the query; count repeated query terms once.
6. Add TF-IDF contributions from the matching postings and sort results.

For example, `JAVA, programming!` becomes `[java, programming]`.
For this dataset, `java -> {1=1, 4=3}`: academic_notice.txt has one occurrence
and java_programming.txt has three. A posting connects a term to a document.
Search uses OR semantics: a document matching any query term can appear.

## 5. Output
Ranked filenames and scores, or a clear no-results message. The index is built
automatically at startup. Menu option 1 rebuilds it after dataset edits; option 3
shows document count, unique indexed terms, and tokens after stop-word removal.
The bundled collection has **6 documents, 75 unique terms, and 120 tokens**.
Labels such as “Fictional demonstration data” are ordinary indexed text too.

## 6. Project structure and classes
```text
spl1-search-prototype-v0/
├── README.md
├── data/
│   ├── academic_notice.txt
│   ├── algorithms.txt
│   ├── information_retrieval.txt
│   ├── java_programming.txt
│   ├── networking.txt
│   └── software_engineering.txt
└── src/
    ├── Main.java
    ├── Document.java
    ├── TextProcessor.java
    ├── InvertedIndex.java
    ├── SearchEngine.java
    └── SearchResult.java
```
- Main: terminal menu, input, results, and error messages.
- Document: document ID and filename.
- TextProcessor: shared manual tokenization and stop-word filtering.
- InvertedIndex: nested maps storing term frequencies and index statistics.
- SearchEngine: file loading, index building, scoring, and result sorting.
- SearchResult: a document paired with its numeric score.

Suggested reading order: Document, TextProcessor, InvertedIndex, SearchResult,
SearchEngine, Main. Compilation creates an `out/` directory of class files.

## 7. How to compile
Install/use **JDK 11 or newer**, with `java` and `javac` on PATH. No Maven or Gradle.
After extracting the ZIP, open a terminal and enter the prototype directory:
```sh
cd spl1-search-prototype-v0
mkdir out
javac -d out src/*.java
```
If `out` already exists, skip `mkdir out`. These commands work in Windows
PowerShell, Command Prompt, and Linux/macOS terminals.

## 8. How to run
From that same prototype directory:
```sh
java -cp out Main
```
Choose 2, enter keywords, and press Enter. Choose 4 to exit. Run from the folder
containing `data/`, not from `src/` or `out/`. Changes to source require recompiling;
changes to data require rebuilding the index. An empty data folder indexes zero
documents. A failed rebuild keeps the previous index.

## 9. Example searches and observed validation
Compiled on OpenJDK 17.0.20 with all lint warnings enabled (none reported).
The environment lacks the `javac` launcher, so its actual bundled javac compiler
was invoked as `java -m jdk.compiler/com.sun.tools.javac.Main -Xlint:all -d out src/*.java`.
The normal JDK commands above are the recommended local workflow.

| Query actually run | Results in displayed order (score) |
| --- | --- |
| software engineering | software_engineering.txt (9.04), algorithms.txt (3.18), java_programming.txt (1.34), networking.txt (1.34) |
| java | java_programming.txt (5.54), academic_notice.txt (1.85) |
| search index | information_retrieval.txt (6.76) |
| volcano | No results found |

All four queries above plus `JAVA, java!!!`, an empty query, `the and`, and
`!!!` matched an independent score calculation. Rebuilding preserved the same counts. The top documents discuss the query topics;
Java frequency explains why java_programming.txt ranks above academic_notice.txt.
These are smoke tests on demonstration data, not a search-quality benchmark.

## 10. Algorithms currently implemented
- Manual character scanning and linear stop-word lookup.
- Frequency counting and inverted-index construction using standard HashMaps.
- Posting lookup and score accumulation for distinct query terms.
- Manual stable insertion sort by descending score, with alphabetical filename
  order for exact ties. Standard sorting is used only to order input filenames.

For each distinct query term `t` found in document `d`:
```text
TF(t,d) = raw number of occurrences of t in d
N       = total number of indexed documents (including empty files)
df(t)   = number of documents containing t
IDF(t)  = ln((N + 1) / (df(t) + 1)) + 1
score(d,q) = sum of TF(t,d) * IDF(t) over distinct matching query terms
```
`ln` is the natural logarithm (`Math.log`). The smoothing avoids zero IDF for
terms present everywhere. An absent term contributes nothing. Scores are not
probabilities or percentages. Sorting uses full precision; display rounds to
2 decimals. For `java`, N=6 and df=2, so IDF=ln(7/3)+1≈1.8473. Three occurrences
score about 5.54, while one occurrence scores about 1.85.

Understand arrays, ArrayList, HashMap, sets, loops, file I/O, tokenization,
postings, TF versus document frequency, logarithms, and insertion sort for viva.
For T tokens, index counting is expected O(T) with HashMaps after preprocessing.
A query visits P matching postings and scans N document scores; ranking R hits
with insertion sort takes O(R²) worst case. This deliberately suits a tiny demo.

## 11. Limitations of Version 0.1
English ASCII keywords only; exact token matches; no stemming, synonyms, typo
correction, Boolean operators, phrase matching, or semantic understanding.
Punctuation is a separator, so C++ becomes c. No PDF/DOCX parsing, recursive
folders, crawler, GUI, networking, persistence, snippets, or Top-K optimization.
Everything is rebuilt in memory. Raw TF favors repetition and longer documents;
there is no length normalization or measured relevance evaluation. Blank,
punctuation-only, stop-word-only, and unknown queries yield no results.
The implementation uses standard collections rather than custom hash tables.

## 12. How this evolves into the final SPL-1 project
Explanatory roadmap only; none of the following is implemented:

V0.1 → larger real/authorized IIT dataset → better preprocessing → positional
index → Boolean queries → phrase search → improved TF-IDF / BM25-style ranking
→ Top-K retrieval → persistence/index storage → snippets → statistics and
benchmarking → evaluation of search quality.

The next three upgrades are: (1) add a small authorized IIT text collection and
known relevant query/document examples, (2) improve token normalization with
explicit tests, (3) store token positions to prepare for phrase search.
